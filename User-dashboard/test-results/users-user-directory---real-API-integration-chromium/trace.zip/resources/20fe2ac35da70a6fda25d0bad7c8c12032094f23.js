import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/StatusMessage.jsx");const _jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];var _jsxFileName = "/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/components/StatusMessage.jsx";
import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fb72e7e4";
export function StatusMessage({ kind, message }) {
	const styles = {
		loading: "text-muted font-mono",
		error: "text-red-700 bg-red-50 border border-red-200 rounded-sm px-4 py-3 font-mono",
		empty: "text-muted font-mono"
	};
	const defaultText = {
		loading: "Loading users…",
		error: "Something went wrong.",
		empty: "No users found."
	};
	return /* @__PURE__ */ _jsxDEV("div", {
		role: kind === "error" ? "alert" : "status",
		className: `text-sm ${styles[kind]}`,
		children: message || defaultText[kind]
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 15,
		columnNumber: 7
	}, this);
}
_c = StatusMessage;
var _c;
$RefreshReg$(_c, "StatusMessage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/StatusMessage.jsx";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/components/StatusMessage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/components/StatusMessage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/components/StatusMessage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6Ijs7QUFBQSxPQUFPLFNBQVMsY0FBYyxFQUFFLE1BQU0sV0FBVztDQUM3QyxNQUFNLFNBQVM7RUFDYixTQUFTO0VBQ1QsT0FBTztFQUNQLE9BQU87Q0FDVDtDQUVBLE1BQU0sY0FBYztFQUNsQixTQUFTO0VBQ1QsT0FBTztFQUNQLE9BQU87Q0FDVDtDQUVBLE9BQ0Usd0JBQUMsT0FBRDtFQUFLLE1BQU0sU0FBUyxVQUFVLFVBQVU7RUFBVSxXQUFXLFdBQVcsT0FBTztZQUM1RSxXQUFXLFlBQVk7Q0FDckI7Ozs7O0FBRVQiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiU3RhdHVzTWVzc2FnZS5qc3giXSwidmVyc2lvbiI6Mywic291cmNlc0NvbnRlbnQiOlsiZXhwb3J0IGZ1bmN0aW9uIFN0YXR1c01lc3NhZ2UoeyBraW5kLCBtZXNzYWdlIH0pIHtcbiAgICBjb25zdCBzdHlsZXMgPSB7XG4gICAgICBsb2FkaW5nOiAndGV4dC1tdXRlZCBmb250LW1vbm8nLFxuICAgICAgZXJyb3I6ICd0ZXh0LXJlZC03MDAgYmctcmVkLTUwIGJvcmRlciBib3JkZXItcmVkLTIwMCByb3VuZGVkLXNtIHB4LTQgcHktMyBmb250LW1vbm8nLFxuICAgICAgZW1wdHk6ICd0ZXh0LW11dGVkIGZvbnQtbW9ubycsXG4gICAgfVxuICBcbiAgICBjb25zdCBkZWZhdWx0VGV4dCA9IHtcbiAgICAgIGxvYWRpbmc6ICdMb2FkaW5nIHVzZXJz4oCmJyxcbiAgICAgIGVycm9yOiAnU29tZXRoaW5nIHdlbnQgd3JvbmcuJyxcbiAgICAgIGVtcHR5OiAnTm8gdXNlcnMgZm91bmQuJyxcbiAgICB9XG4gIFxuICAgIHJldHVybiAoXG4gICAgICA8ZGl2IHJvbGU9e2tpbmQgPT09ICdlcnJvcicgPyAnYWxlcnQnIDogJ3N0YXR1cyd9IGNsYXNzTmFtZT17YHRleHQtc20gJHtzdHlsZXNba2luZF19YH0+XG4gICAgICAgIHttZXNzYWdlIHx8IGRlZmF1bHRUZXh0W2tpbmRdfVxuICAgICAgPC9kaXY+XG4gICAgKVxuICB9Il19