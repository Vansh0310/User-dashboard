const useEffect = __vite__cjsImport0_react["useEffect"]; const useState = __vite__cjsImport0_react["useState"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fb72e7e4";
import { fetchUsers } from "/src/api/user.js";
export function useUsers(count) {
	const [users, setUsers] = useState(null);
	const [isLoading, setIsLoading] = useState(true);
	const [error, setError] = useState(null);
	async function load() {
		setIsLoading(true);
		setError(null);
		try {
			const data = await fetchUsers(count);
			setUsers(data);
		} catch (err) {
			setError(err.message);
		} finally {
			setIsLoading(false);
		}
	}
	useEffect(() => {
		load();
	}, [count]);
	return {
		users,
		isLoading,
		error
	};
}

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxXQUFXLGdCQUFnQjtBQUNwQyxTQUFTLGtCQUFrQjtBQUUzQixPQUFPLFNBQVMsU0FBUyxPQUFPO0NBQzlCLE1BQU0sQ0FBQyxPQUFPLFlBQVksU0FBUyxJQUFJO0NBQ3ZDLE1BQU0sQ0FBQyxXQUFXLGdCQUFnQixTQUFTLElBQUk7Q0FDL0MsTUFBTSxDQUFDLE9BQU8sWUFBWSxTQUFTLElBQUk7Q0FFdkMsZUFBZSxPQUFPO0VBQ3BCLGFBQWEsSUFBSTtFQUNqQixTQUFTLElBQUk7RUFDYixJQUFJO0dBQ0YsTUFBTSxPQUFPLE1BQU0sV0FBVyxLQUFLO0dBQ25DLFNBQVMsSUFBSTtFQUNmLFNBQVMsS0FBSztHQUNaLFNBQVMsSUFBSSxPQUFPO0VBQ3RCLFVBQVU7R0FDUixhQUFhLEtBQUs7RUFDcEI7Q0FDRjtDQUVBLGdCQUFnQjtFQUNkLEtBQUs7Q0FDUCxHQUFHLENBQUMsS0FBSyxDQUFDO0NBRVYsT0FBTztFQUFFO0VBQU87RUFBVztDQUFNO0FBQ25DIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbInVzZVVzZXJzLmpzIl0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IGZldGNoVXNlcnMgfSBmcm9tICcuLi9hcGkvdXNlcidcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZVVzZXJzKGNvdW50KSB7XG4gIGNvbnN0IFt1c2Vycywgc2V0VXNlcnNdID0gdXNlU3RhdGUobnVsbClcbiAgY29uc3QgW2lzTG9hZGluZywgc2V0SXNMb2FkaW5nXSA9IHVzZVN0YXRlKHRydWUpXG4gIGNvbnN0IFtlcnJvciwgc2V0RXJyb3JdID0gdXNlU3RhdGUobnVsbClcblxuICBhc3luYyBmdW5jdGlvbiBsb2FkKCkge1xuICAgIHNldElzTG9hZGluZyh0cnVlKVxuICAgIHNldEVycm9yKG51bGwpXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IGRhdGEgPSBhd2FpdCBmZXRjaFVzZXJzKGNvdW50KVxuICAgICAgc2V0VXNlcnMoZGF0YSlcbiAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgIHNldEVycm9yKGVyci5tZXNzYWdlKVxuICAgIH0gZmluYWxseSB7XG4gICAgICBzZXRJc0xvYWRpbmcoZmFsc2UpXG4gICAgfVxuICB9XG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBsb2FkKClcbiAgfSwgW2NvdW50XSlcblxuICByZXR1cm4geyB1c2VycywgaXNMb2FkaW5nLCBlcnJvciB9XG59XG4iXX0=