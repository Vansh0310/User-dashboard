import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UsersPage.jsx");const useMemo = __vite__cjsImport0_react["useMemo"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fb72e7e4";
import { useUsers } from "/src/hooks/useUsers.js";
import { StatusMessage } from "/src/components/StatusMessage.jsx";
import { UserList } from "/src/components/UserList.jsx?t=1786958910609";
var _jsxFileName = "/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/pages/UsersPage.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fb72e7e4";
var _s = $RefreshSig$();
export function UsersPage() {
	_s();
	const { users, isLoading, error } = useUsers(15);
	const status = useMemo(() => {
		if (isLoading) return "loading";
		if (error) return "error";
		if (users.length === 0) return "empty";
		return null;
	}, [
		isLoading,
		error,
		users
	]);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "p-6",
		children: [
			/* @__PURE__ */ _jsxDEV("h1", {
				className: "font-display text-2xl text-ink mb-1",
				children: "Users"
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 18,
				columnNumber: 7
			}, this),
			/* @__PURE__ */ _jsxDEV("p", {
				className: "text-sm text-muted mb-6 font-mono",
				children: "Click a user to see their full details."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 19,
				columnNumber: 7
			}, this),
			status && /* @__PURE__ */ _jsxDEV(StatusMessage, {
				kind: status,
				message: error
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 20,
				columnNumber: 18
			}, this),
			status === null && /* @__PURE__ */ _jsxDEV(UserList, { users }, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 21,
				columnNumber: 27
			}, this)
		]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
_s(UsersPage, "UveIlYn773LZFoBuPVo2a5a2TJw=", false, function() {
	return [useUsers];
});
_c = UsersPage;
var _c;
$RefreshReg$(_c, "UsersPage");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/UsersPage.jsx?t=1786958910609";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/pages/UsersPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/pages/UsersPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/pages/UsersPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxlQUFlO0FBQ3hCLFNBQVMsZ0JBQWdCO0FBQ3pCLFNBQVMscUJBQXFCO0FBQzlCLFNBQVMsZ0JBQWdCOzs7O0FBRXpCLE9BQU8sU0FBUyxZQUFZOztDQUMxQixNQUFNLEVBQUUsT0FBTyxXQUFXLFVBQVUsU0FBUyxFQUFFO0NBRS9DLE1BQU0sU0FBUyxjQUFjO0VBQzNCLElBQUksV0FBVyxPQUFPO0VBQ3RCLElBQUksT0FBTyxPQUFPO0VBQ2xCLElBQUksTUFBTSxXQUFXLEdBQUcsT0FBTztFQUMvQixPQUFPO0NBQ1QsR0FBRztFQUFDO0VBQVc7RUFBTztDQUFLLENBQUM7Q0FFNUIsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmO0dBQ0Usd0JBQUMsTUFBRDtJQUFJLFdBQVU7Y0FBc0M7R0FBUzs7Ozs7R0FDN0Qsd0JBQUMsS0FBRDtJQUFHLFdBQVU7Y0FBb0M7R0FBMEM7Ozs7O0dBQzFGLFVBQVUsd0JBQUMsZUFBRDtJQUFlLE1BQU07SUFBUSxTQUFTO0dBQVE7Ozs7O0dBQ3hELFdBQVcsUUFBUSx3QkFBQyxVQUFELEVBQWlCLE1BQVE7Ozs7O0VBQzFDOzs7Ozs7QUFFVCIsIm5hbWVzIjpbXSwic291cmNlcyI6WyJVc2Vyc1BhZ2UuanN4Il0sInZlcnNpb24iOjMsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1lbW8gfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7IHVzZVVzZXJzIH0gZnJvbSAnLi4vaG9va3MvdXNlVXNlcnMnXG5pbXBvcnQgeyBTdGF0dXNNZXNzYWdlIH0gZnJvbSAnLi4vY29tcG9uZW50cy9TdGF0dXNNZXNzYWdlJ1xuaW1wb3J0IHsgVXNlckxpc3QgfSBmcm9tICcuLi9jb21wb25lbnRzL1VzZXJMaXN0J1xuXG5leHBvcnQgZnVuY3Rpb24gVXNlcnNQYWdlKCkge1xuICBjb25zdCB7IHVzZXJzLCBpc0xvYWRpbmcsIGVycm9yIH0gPSB1c2VVc2VycygxNSlcblxuICBjb25zdCBzdGF0dXMgPSB1c2VNZW1vKCgpID0+IHtcbiAgICBpZiAoaXNMb2FkaW5nKSByZXR1cm4gJ2xvYWRpbmcnXG4gICAgaWYgKGVycm9yKSByZXR1cm4gJ2Vycm9yJ1xuICAgIGlmICh1c2Vycy5sZW5ndGggPT09IDApIHJldHVybiAnZW1wdHknXG4gICAgcmV0dXJuIG51bGxcbiAgfSwgW2lzTG9hZGluZywgZXJyb3IsIHVzZXJzXSlcblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicC02XCI+XG4gICAgICA8aDEgY2xhc3NOYW1lPVwiZm9udC1kaXNwbGF5IHRleHQtMnhsIHRleHQtaW5rIG1iLTFcIj5Vc2VyczwvaDE+XG4gICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXNtIHRleHQtbXV0ZWQgbWItNiBmb250LW1vbm9cIj5DbGljayBhIHVzZXIgdG8gc2VlIHRoZWlyIGZ1bGwgZGV0YWlscy48L3A+XG4gICAgICB7c3RhdHVzICYmIDxTdGF0dXNNZXNzYWdlIGtpbmQ9e3N0YXR1c30gbWVzc2FnZT17ZXJyb3J9IC8+fVxuICAgICAge3N0YXR1cyA9PT0gbnVsbCAmJiA8VXNlckxpc3QgdXNlcnM9e3VzZXJzfSAvPn1cbiAgICA8L2Rpdj5cbiAgKVxufSJdfQ==