import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/pages/UserDetailPage.jsx");const useContext = __vite__cjsImport0_react["useContext"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fb72e7e4";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=fb72e7e4";
import { Link } from "/node_modules/.vite/deps/react-aria-components.js?v=fb72e7e4";
import { SelectedUserContext } from "/src/context/SelectedUserContext.js";
import { StatusMessage } from "/src/components/StatusMessage.jsx";
var _jsxFileName = "/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/pages/UserDetailPage.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fb72e7e4";
var _s = $RefreshSig$();
export function UserDetailPage() {
	_s();
	const navigate = useNavigate();
	const { selectedUser } = useContext(SelectedUserContext);
	return /* @__PURE__ */ _jsxDEV("div", {
		className: "max-w-xl mx-auto px-6 py-10",
		children: [/* @__PURE__ */ _jsxDEV(Link, {
			onPress: () => navigate("/"),
			className: "font-mono text-xs uppercase tracking-wide text-ledger cursor-pointer outline-none\n                   data-[hovered]:underline\n                   data-[focus-visible]:ring-1 data-[focus-visible]:ring-ledger rounded-sm",
			children: "← Back to directory"
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("div", {
			className: "mt-8",
			children: [!selectedUser && /* @__PURE__ */ _jsxDEV(StatusMessage, {
				kind: "error",
				message: "No user data available. Please go back and select a user from the list."
			}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 24,
				columnNumber: 11
			}, this), selectedUser && /* @__PURE__ */ _jsxDEV("div", {
				className: "border border-rule bg-white",
				children: [/* @__PURE__ */ _jsxDEV("div", {
					className: "flex items-center gap-5 p-6 border-b border-dotted border-rule",
					children: [/* @__PURE__ */ _jsxDEV("img", {
						src: selectedUser.picture.large,
						alt: "",
						className: "h-16 w-16 rounded-sm object-cover border border-rule"
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 30,
						columnNumber: 15
					}, this), /* @__PURE__ */ _jsxDEV("div", { children: [/* @__PURE__ */ _jsxDEV("p", {
						className: "font-display text-2xl text-ink",
						children: [
							selectedUser.name.title,
							" ",
							selectedUser.name.first,
							" ",
							selectedUser.name.last
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 36,
						columnNumber: 17
					}, this), /* @__PURE__ */ _jsxDEV("p", {
						className: "font-mono text-xs text-muted mt-1",
						children: selectedUser.email
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 39,
						columnNumber: 17
					}, this)] }, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 35,
						columnNumber: 15
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 29,
					columnNumber: 13
				}, this), /* @__PURE__ */ _jsxDEV("dl", {
					className: "grid grid-cols-1 sm:grid-cols-2",
					children: [
						/* @__PURE__ */ _jsxDEV(Detail, {
							label: "Phone",
							value: selectedUser.phone
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 44,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Detail, {
							label: "Cell",
							value: selectedUser.cell
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 45,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Detail, {
							label: "Gender",
							value: selectedUser.gender
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 46,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Detail, {
							label: "Date of birth",
							value: new Date(selectedUser.dob.date).toLocaleDateString()
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 47,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Detail, {
							label: "Address",
							value: `${selectedUser.location.street.number} ${selectedUser.location.street.name}, ${selectedUser.location.city}, ${selectedUser.location.country}`,
							full: true
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 48,
							columnNumber: 15
						}, this),
						/* @__PURE__ */ _jsxDEV(Detail, {
							label: "Username",
							value: selectedUser.login.username
						}, void 0, false, {
							fileName: _jsxFileName,
							lineNumber: 53,
							columnNumber: 15
						}, this)
					]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 13
				}, this)]
			}, void 0, true, {
				fileName: _jsxFileName,
				lineNumber: 28,
				columnNumber: 11
			}, this)]
		}, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 22,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 12,
		columnNumber: 5
	}, this);
}
_s(UserDetailPage, "icWR5x0KfbQIkKDyYYMmKe6xZkU=", false, function() {
	return [useNavigate];
});
_c = UserDetailPage;
function Detail({ label, value, full }) {
	return /* @__PURE__ */ _jsxDEV("div", {
		className: `px-6 py-4 border-b border-dotted border-rule ${full ? "sm:col-span-2" : ""}`,
		children: [/* @__PURE__ */ _jsxDEV("dt", {
			className: "font-mono text-[11px] uppercase tracking-wide text-muted",
			children: label
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 65,
			columnNumber: 7
		}, this), /* @__PURE__ */ _jsxDEV("dd", {
			className: "text-ink mt-1",
			children: value
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 66,
			columnNumber: 7
		}, this)]
	}, void 0, true, {
		fileName: _jsxFileName,
		lineNumber: 64,
		columnNumber: 5
	}, this);
}
_c2 = Detail;
var _c, _c2;
$RefreshReg$(_c, "UserDetailPage");
$RefreshReg$(_c2, "Detail");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/pages/UserDetailPage.jsx?t=1786957584966";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/pages/UserDetailPage.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/pages/UserDetailPage.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/pages/UserDetailPage.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxtQkFBbUI7QUFDNUIsU0FBUyxZQUFZO0FBQ3JCLFNBQVMsMkJBQTJCO0FBQ3BDLFNBQVMscUJBQXFCOzs7O0FBRTlCLE9BQU8sU0FBUyxpQkFBaUI7O0NBQy9CLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sRUFBRSxpQkFBaUIsV0FBVyxtQkFBbUI7Q0FFdkQsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVTtZQUFmLENBQ0Usd0JBQUMsTUFBRDtHQUNFLGVBQWUsU0FBUyxHQUFHO0dBQzNCLFdBQVU7YUFHWDtFQUVLOzs7O1lBRU4sd0JBQUMsT0FBRDtHQUFLLFdBQVU7YUFBZixDQUNHLENBQUMsZ0JBQ0Esd0JBQUMsZUFBRDtJQUFlLE1BQUs7SUFBUSxTQUFRO0dBQTJFOzs7O2FBR2hILGdCQUNDLHdCQUFDLE9BQUQ7SUFBSyxXQUFVO2NBQWYsQ0FDRSx3QkFBQyxPQUFEO0tBQUssV0FBVTtlQUFmLENBQ0Usd0JBQUMsT0FBRDtNQUNFLEtBQUssYUFBYSxRQUFRO01BQzFCLEtBQUk7TUFDSixXQUFVO0tBQ1g7Ozs7ZUFDRCx3QkFBQyxPQUFELGFBQ0Usd0JBQUMsS0FBRDtNQUFHLFdBQVU7Z0JBQWI7T0FDRyxhQUFhLEtBQUs7T0FBTTtPQUFFLGFBQWEsS0FBSztPQUFNO09BQUUsYUFBYSxLQUFLO01BQ3RFOzs7OztlQUNILHdCQUFDLEtBQUQ7TUFBRyxXQUFVO2dCQUFxQyxhQUFhO0tBQVM7Ozs7YUFDckU7Ozs7YUFDRjs7Ozs7Y0FFTCx3QkFBQyxNQUFEO0tBQUksV0FBVTtlQUFkO01BQ0Usd0JBQUMsUUFBRDtPQUFRLE9BQU07T0FBUSxPQUFPLGFBQWE7TUFBUTs7Ozs7TUFDbEQsd0JBQUMsUUFBRDtPQUFRLE9BQU07T0FBTyxPQUFPLGFBQWE7TUFBTzs7Ozs7TUFDaEQsd0JBQUMsUUFBRDtPQUFRLE9BQU07T0FBUyxPQUFPLGFBQWE7TUFBUzs7Ozs7TUFDcEQsd0JBQUMsUUFBRDtPQUFRLE9BQU07T0FBZ0IsT0FBTyxJQUFJLEtBQUssYUFBYSxJQUFJLElBQUksQ0FBQyxDQUFDLG1CQUFtQjtNQUFJOzs7OztNQUM1Rix3QkFBQyxRQUFEO09BQ0UsT0FBTTtPQUNOLE9BQU8sR0FBRyxhQUFhLFNBQVMsT0FBTyxPQUFPLEdBQUcsYUFBYSxTQUFTLE9BQU8sS0FBSyxJQUFJLGFBQWEsU0FBUyxLQUFLLElBQUksYUFBYSxTQUFTO09BQzVJO01BQ0Q7Ozs7O01BQ0Qsd0JBQUMsUUFBRDtPQUFRLE9BQU07T0FBVyxPQUFPLGFBQWEsTUFBTTtNQUFXOzs7OztLQUM1RDs7Ozs7WUFDRDs7Ozs7V0FFSjs7Ozs7VUFDRjs7Ozs7O0FBRVQ7Ozs7O0FBRUEsU0FBUyxPQUFPLEVBQUUsT0FBTyxPQUFPLFFBQVE7Q0FDdEMsT0FDRSx3QkFBQyxPQUFEO0VBQUssV0FBVyxnREFBZ0QsT0FBTyxrQkFBa0I7WUFBekYsQ0FDRSx3QkFBQyxNQUFEO0dBQUksV0FBVTthQUE0RDtFQUFVOzs7O1lBQ3BGLHdCQUFDLE1BQUQ7R0FBSSxXQUFVO2FBQWlCO0VBQVU7Ozs7VUFDdEM7Ozs7OztBQUVUIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlVzZXJEZXRhaWxQYWdlLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyB1c2VOYXZpZ2F0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBMaW5rIH0gZnJvbSAncmVhY3QtYXJpYS1jb21wb25lbnRzJ1xuaW1wb3J0IHsgU2VsZWN0ZWRVc2VyQ29udGV4dCB9IGZyb20gJy4uL2NvbnRleHQvU2VsZWN0ZWRVc2VyQ29udGV4dCdcbmltcG9ydCB7IFN0YXR1c01lc3NhZ2UgfSBmcm9tICcuLi9jb21wb25lbnRzL1N0YXR1c01lc3NhZ2UnXG5cbmV4cG9ydCBmdW5jdGlvbiBVc2VyRGV0YWlsUGFnZSgpIHtcbiAgY29uc3QgbmF2aWdhdGUgPSB1c2VOYXZpZ2F0ZSgpXG4gIGNvbnN0IHsgc2VsZWN0ZWRVc2VyIH0gPSB1c2VDb250ZXh0KFNlbGVjdGVkVXNlckNvbnRleHQpXG5cbiAgcmV0dXJuICggXG4gICAgPGRpdiBjbGFzc05hbWU9XCJtYXgtdy14bCBteC1hdXRvIHB4LTYgcHktMTBcIj5cbiAgICAgIDxMaW5rXG4gICAgICAgIG9uUHJlc3M9eygpID0+IG5hdmlnYXRlKCcvJyl9XG4gICAgICAgIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXhzIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtbGVkZ2VyIGN1cnNvci1wb2ludGVyIG91dGxpbmUtbm9uZVxuICAgICAgICAgICAgICAgICAgIGRhdGEtW2hvdmVyZWRdOnVuZGVybGluZVxuICAgICAgICAgICAgICAgICAgIGRhdGEtW2ZvY3VzLXZpc2libGVdOnJpbmctMSBkYXRhLVtmb2N1cy12aXNpYmxlXTpyaW5nLWxlZGdlciByb3VuZGVkLXNtXCJcbiAgICAgID5cbiAgICAgICAg4oaQIEJhY2sgdG8gZGlyZWN0b3J5XG4gICAgICA8L0xpbms+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtOFwiPlxuICAgICAgICB7IXNlbGVjdGVkVXNlciAmJiAoXG4gICAgICAgICAgPFN0YXR1c01lc3NhZ2Uga2luZD1cImVycm9yXCIgbWVzc2FnZT1cIk5vIHVzZXIgZGF0YSBhdmFpbGFibGUuIFBsZWFzZSBnbyBiYWNrIGFuZCBzZWxlY3QgYSB1c2VyIGZyb20gdGhlIGxpc3QuXCIgLz5cbiAgICAgICAgKX1cblxuICAgICAgICB7c2VsZWN0ZWRVc2VyICYmIChcbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJvcmRlciBib3JkZXItcnVsZSBiZy13aGl0ZVwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBnYXAtNSBwLTYgYm9yZGVyLWIgYm9yZGVyLWRvdHRlZCBib3JkZXItcnVsZVwiPlxuICAgICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgICAgc3JjPXtzZWxlY3RlZFVzZXIucGljdHVyZS5sYXJnZX1cbiAgICAgICAgICAgICAgICBhbHQ9XCJcIlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtMTYgdy0xNiByb3VuZGVkLXNtIG9iamVjdC1jb3ZlciBib3JkZXIgYm9yZGVyLXJ1bGVcIlxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImZvbnQtZGlzcGxheSB0ZXh0LTJ4bCB0ZXh0LWlua1wiPlxuICAgICAgICAgICAgICAgICAge3NlbGVjdGVkVXNlci5uYW1lLnRpdGxlfSB7c2VsZWN0ZWRVc2VyLm5hbWUuZmlyc3R9IHtzZWxlY3RlZFVzZXIubmFtZS5sYXN0fVxuICAgICAgICAgICAgICAgIDwvcD5cbiAgICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC14cyB0ZXh0LW11dGVkIG10LTFcIj57c2VsZWN0ZWRVc2VyLmVtYWlsfTwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRsIGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgc206Z3JpZC1jb2xzLTJcIj5cbiAgICAgICAgICAgICAgPERldGFpbCBsYWJlbD1cIlBob25lXCIgdmFsdWU9e3NlbGVjdGVkVXNlci5waG9uZX0gLz5cbiAgICAgICAgICAgICAgPERldGFpbCBsYWJlbD1cIkNlbGxcIiB2YWx1ZT17c2VsZWN0ZWRVc2VyLmNlbGx9IC8+XG4gICAgICAgICAgICAgIDxEZXRhaWwgbGFiZWw9XCJHZW5kZXJcIiB2YWx1ZT17c2VsZWN0ZWRVc2VyLmdlbmRlcn0gLz5cbiAgICAgICAgICAgICAgPERldGFpbCBsYWJlbD1cIkRhdGUgb2YgYmlydGhcIiB2YWx1ZT17bmV3IERhdGUoc2VsZWN0ZWRVc2VyLmRvYi5kYXRlKS50b0xvY2FsZURhdGVTdHJpbmcoKX0gLz5cbiAgICAgICAgICAgICAgPERldGFpbFxuICAgICAgICAgICAgICAgIGxhYmVsPVwiQWRkcmVzc1wiXG4gICAgICAgICAgICAgICAgdmFsdWU9e2Ake3NlbGVjdGVkVXNlci5sb2NhdGlvbi5zdHJlZXQubnVtYmVyfSAke3NlbGVjdGVkVXNlci5sb2NhdGlvbi5zdHJlZXQubmFtZX0sICR7c2VsZWN0ZWRVc2VyLmxvY2F0aW9uLmNpdHl9LCAke3NlbGVjdGVkVXNlci5sb2NhdGlvbi5jb3VudHJ5fWB9XG4gICAgICAgICAgICAgICAgZnVsbFxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICA8RGV0YWlsIGxhYmVsPVwiVXNlcm5hbWVcIiB2YWx1ZT17c2VsZWN0ZWRVc2VyLmxvZ2luLnVzZXJuYW1lfSAvPlxuICAgICAgICAgICAgPC9kbD5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApXG59XG5cbmZ1bmN0aW9uIERldGFpbCh7IGxhYmVsLCB2YWx1ZSwgZnVsbCB9KSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2BweC02IHB5LTQgYm9yZGVyLWIgYm9yZGVyLWRvdHRlZCBib3JkZXItcnVsZSAke2Z1bGwgPyAnc206Y29sLXNwYW4tMicgOiAnJ31gfT5cbiAgICAgIDxkdCBjbGFzc05hbWU9XCJmb250LW1vbm8gdGV4dC1bMTFweF0gdXBwZXJjYXNlIHRyYWNraW5nLXdpZGUgdGV4dC1tdXRlZFwiPntsYWJlbH08L2R0PlxuICAgICAgPGRkIGNsYXNzTmFtZT1cInRleHQtaW5rIG10LTFcIj57dmFsdWV9PC9kZD5cbiAgICA8L2Rpdj5cbiAgKVxufSJdfQ==