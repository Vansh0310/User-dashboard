import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/UserList.jsx");const useContext = __vite__cjsImport0_react["useContext"];const _jsxDEV = __vite__cjsImport4_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fb72e7e4";
import { GridList, GridListItem } from "/node_modules/.vite/deps/react-aria-components.js?v=fb72e7e4";
import { useNavigate } from "/node_modules/.vite/deps/react-router-dom.js?v=fb72e7e4";
import { SelectedUserContext } from "/src/context/SelectedUserContext.js";
var _jsxFileName = "/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/components/UserList.jsx";
import __vite__cjsImport4_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fb72e7e4";
var _s = $RefreshSig$();
export function UserList({ users }) {
	_s();
	const navigate = useNavigate();
	const { setSelectedUser } = useContext(SelectedUserContext);
	function handleAction(id) {
		const user = users.find((person) => person.id === id);
		setSelectedUser(user);
		navigate(`/users/${id}`);
	}
	return /* @__PURE__ */ _jsxDEV(GridList, {
		"aria-label": "Users",
		onAction: handleAction,
		className: "border-t border-rule",
		children: users.map((user, position) => /* @__PURE__ */ _jsxDEV(GridListItem, {
			id: user.id,
			textValue: `${user.name.first} ${user.name.last}`,
			className: "group relative flex items-center gap-5 border-b border-dotted border-rule py-4 pl-2 pr-4 cursor-pointer outline-none\n                     data-[hovered]:bg-ink/[0.03]\n                     data-[focus-visible]:bg-ledger/[0.06]",
			children: [
				/* @__PURE__ */ _jsxDEV("span", { className: "absolute left-0 top-0 h-full w-[3px] bg-ledger scale-y-0 transition-transform duration-150 group-data-[hovered]:scale-y-100 group-data-[focus-visible]:scale-y-100" }, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 31,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "font-mono text-xs text-muted w-8 shrink-0 text-right tabular-nums",
					children: String(position + 1).padStart(2, "0")
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 33,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("img", {
					src: user.picture.thumbnail,
					alt: "",
					className: "h-11 w-11 rounded-sm object-cover border border-rule flex-shrink-0"
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 37,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "min-w-0 flex-1",
					children: [/* @__PURE__ */ _jsxDEV("span", {
						"data-testid": "user-name",
						className: "block font-display text-lg text-ink truncate",
						children: [
							user.name.first,
							" ",
							user.name.last
						]
					}, void 0, true, {
						fileName: _jsxFileName,
						lineNumber: 44,
						columnNumber: 13
					}, this), /* @__PURE__ */ _jsxDEV("span", {
						className: "block font-mono text-xs text-muted truncate",
						children: user.email
					}, void 0, false, {
						fileName: _jsxFileName,
						lineNumber: 47,
						columnNumber: 13
					}, this)]
				}, void 0, true, {
					fileName: _jsxFileName,
					lineNumber: 43,
					columnNumber: 11
				}, this),
				/* @__PURE__ */ _jsxDEV("span", {
					className: "hidden sm:block font-mono text-[11px] uppercase tracking-wide text-muted",
					children: user.location.country
				}, void 0, false, {
					fileName: _jsxFileName,
					lineNumber: 52,
					columnNumber: 11
				}, this)
			]
		}, user.id, true, {
			fileName: _jsxFileName,
			lineNumber: 23,
			columnNumber: 9
		}, this))
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 17,
		columnNumber: 5
	}, this);
}
_s(UserList, "T3vgvWURlR0+5FoXu39Evcaquh4=", false, function() {
	return [useNavigate];
});
_c = UserList;
var _c;
$RefreshReg$(_c, "UserList");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/components/UserList.jsx?t=1786958910609";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/components/UserList.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/components/UserList.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/components/UserList.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxrQkFBa0I7QUFDM0IsU0FBUyxVQUFVLG9CQUFvQjtBQUN2QyxTQUFTLG1CQUFtQjtBQUM1QixTQUFTLDJCQUEyQjs7OztBQUVwQyxPQUFPLFNBQVMsU0FBUyxFQUFFLFNBQVM7O0NBQ2hDLE1BQU0sV0FBVyxZQUFZO0NBQzdCLE1BQU0sRUFBRSxvQkFBb0IsV0FBVyxtQkFBbUI7Q0FFMUQsU0FBUyxhQUFhLElBQUk7RUFDdEIsTUFBTSxPQUFPLE1BQU0sTUFBTSxXQUFXLE9BQU8sT0FBTyxFQUFFO0VBQ3BELGdCQUFnQixJQUFJO0VBQ3BCLFNBQVMsVUFBVSxJQUFJO0NBQ3pCO0NBRUosT0FDRSx3QkFBQyxVQUFEO0VBQ0UsY0FBVztFQUNYLFVBQVU7RUFDVixXQUFVO1lBRVQsTUFBTSxLQUFLLE1BQU0sYUFDaEIsd0JBQUMsY0FBRDtHQUVFLElBQUksS0FBSztHQUNULFdBQVcsR0FBRyxLQUFLLEtBQUssTUFBTSxHQUFHLEtBQUssS0FBSztHQUMzQyxXQUFVO2FBSlo7SUFRRSx3QkFBQyxRQUFELEVBQU0sV0FBVSxxS0FBc0s7Ozs7O0lBRXRMLHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQ2IsT0FBTyxXQUFXLENBQUMsQ0FBQyxDQUFDLFNBQVMsR0FBRyxHQUFHO0lBQ2pDOzs7OztJQUVOLHdCQUFDLE9BQUQ7S0FDRSxLQUFLLEtBQUssUUFBUTtLQUNsQixLQUFJO0tBQ0osV0FBVTtJQUNYOzs7OztJQUVELHdCQUFDLFFBQUQ7S0FBTSxXQUFVO2VBQWhCLENBQ0Usd0JBQUMsUUFBRDtNQUFNLGVBQVk7TUFBWSxXQUFVO2dCQUF4QztPQUNHLEtBQUssS0FBSztPQUFNO09BQUUsS0FBSyxLQUFLO01BQ3pCOzs7OztlQUNOLHdCQUFDLFFBQUQ7TUFBTSxXQUFVO2dCQUNiLEtBQUs7S0FDRjs7OzthQUNGOzs7Ozs7SUFFTix3QkFBQyxRQUFEO0tBQU0sV0FBVTtlQUNiLEtBQUssU0FBUztJQUNYOzs7OztHQUNNO0tBL0JQLEtBQUs7Ozs7U0ErQkUsQ0FDZjtDQUNPOzs7OztBQUVkIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIlVzZXJMaXN0LmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VDb250ZXh0IH0gZnJvbSAncmVhY3QnXG5pbXBvcnQgeyBHcmlkTGlzdCwgR3JpZExpc3RJdGVtIH0gZnJvbSAncmVhY3QtYXJpYS1jb21wb25lbnRzJ1xuaW1wb3J0IHsgdXNlTmF2aWdhdGUgfSBmcm9tICdyZWFjdC1yb3V0ZXItZG9tJ1xuaW1wb3J0IHsgU2VsZWN0ZWRVc2VyQ29udGV4dCB9IGZyb20gJy4uL2NvbnRleHQvU2VsZWN0ZWRVc2VyQ29udGV4dCdcblxuZXhwb3J0IGZ1bmN0aW9uIFVzZXJMaXN0KHsgdXNlcnMgfSkge1xuICAgIGNvbnN0IG5hdmlnYXRlID0gdXNlTmF2aWdhdGUoKVxuICAgIGNvbnN0IHsgc2V0U2VsZWN0ZWRVc2VyIH0gPSB1c2VDb250ZXh0KFNlbGVjdGVkVXNlckNvbnRleHQpXG5cbiAgICBmdW5jdGlvbiBoYW5kbGVBY3Rpb24oaWQpIHtcbiAgICAgICAgY29uc3QgdXNlciA9IHVzZXJzLmZpbmQoKHBlcnNvbikgPT4gcGVyc29uLmlkID09PSBpZClcbiAgICAgICAgc2V0U2VsZWN0ZWRVc2VyKHVzZXIpXG4gICAgICAgIG5hdmlnYXRlKGAvdXNlcnMvJHtpZH1gKVxuICAgICAgfVxuICAgICAgXG4gIHJldHVybiAoXG4gICAgPEdyaWRMaXN0XG4gICAgICBhcmlhLWxhYmVsPVwiVXNlcnNcIlxuICAgICAgb25BY3Rpb249e2hhbmRsZUFjdGlvbn1cbiAgICAgIGNsYXNzTmFtZT1cImJvcmRlci10IGJvcmRlci1ydWxlXCJcbiAgICA+XG4gICAgICB7dXNlcnMubWFwKCh1c2VyLCBwb3NpdGlvbikgPT4gKFxuICAgICAgICA8R3JpZExpc3RJdGVtXG4gICAgICAgICAga2V5PXt1c2VyLmlkfVxuICAgICAgICAgIGlkPXt1c2VyLmlkfVxuICAgICAgICAgIHRleHRWYWx1ZT17YCR7dXNlci5uYW1lLmZpcnN0fSAke3VzZXIubmFtZS5sYXN0fWB9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiZ3JvdXAgcmVsYXRpdmUgZmxleCBpdGVtcy1jZW50ZXIgZ2FwLTUgYm9yZGVyLWIgYm9yZGVyLWRvdHRlZCBib3JkZXItcnVsZSBweS00IHBsLTIgcHItNCBjdXJzb3ItcG9pbnRlciBvdXRsaW5lLW5vbmVcbiAgICAgICAgICAgICAgICAgICAgIGRhdGEtW2hvdmVyZWRdOmJnLWluay9bMC4wM11cbiAgICAgICAgICAgICAgICAgICAgIGRhdGEtW2ZvY3VzLXZpc2libGVdOmJnLWxlZGdlci9bMC4wNl1cIlxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYWJzb2x1dGUgbGVmdC0wIHRvcC0wIGgtZnVsbCB3LVszcHhdIGJnLWxlZGdlciBzY2FsZS15LTAgdHJhbnNpdGlvbi10cmFuc2Zvcm0gZHVyYXRpb24tMTUwIGdyb3VwLWRhdGEtW2hvdmVyZWRdOnNjYWxlLXktMTAwIGdyb3VwLWRhdGEtW2ZvY3VzLXZpc2libGVdOnNjYWxlLXktMTAwXCIgLz5cblxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbW9ubyB0ZXh0LXhzIHRleHQtbXV0ZWQgdy04IHNocmluay0wIHRleHQtcmlnaHQgdGFidWxhci1udW1zXCI+XG4gICAgICAgICAgICB7U3RyaW5nKHBvc2l0aW9uICsgMSkucGFkU3RhcnQoMiwgJzAnKX1cbiAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICA8aW1nXG4gICAgICAgICAgICBzcmM9e3VzZXIucGljdHVyZS50aHVtYm5haWx9XG4gICAgICAgICAgICBhbHQ9XCJcIlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC0xMSB3LTExIHJvdW5kZWQtc20gb2JqZWN0LWNvdmVyIGJvcmRlciBib3JkZXItcnVsZSBmbGV4LXNocmluay0wXCJcbiAgICAgICAgICAvPlxuXG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwibWluLXctMCBmbGV4LTFcIj5cbiAgICAgICAgICAgIDxzcGFuIGRhdGEtdGVzdGlkPVwidXNlci1uYW1lXCIgY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1kaXNwbGF5IHRleHQtbGcgdGV4dC1pbmsgdHJ1bmNhdGVcIj5cbiAgICAgICAgICAgICAge3VzZXIubmFtZS5maXJzdH0ge3VzZXIubmFtZS5sYXN0fVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiYmxvY2sgZm9udC1tb25vIHRleHQteHMgdGV4dC1tdXRlZCB0cnVuY2F0ZVwiPlxuICAgICAgICAgICAgICB7dXNlci5lbWFpbH1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L3NwYW4+XG5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJoaWRkZW4gc206YmxvY2sgZm9udC1tb25vIHRleHQtWzExcHhdIHVwcGVyY2FzZSB0cmFja2luZy13aWRlIHRleHQtbXV0ZWRcIj5cbiAgICAgICAgICAgIHt1c2VyLmxvY2F0aW9uLmNvdW50cnl9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L0dyaWRMaXN0SXRlbT5cbiAgICAgICkpfVxuICAgIDwvR3JpZExpc3Q+XG4gIClcbn0iXX0=