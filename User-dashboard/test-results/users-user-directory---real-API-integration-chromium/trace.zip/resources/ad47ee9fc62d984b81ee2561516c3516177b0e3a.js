import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.jsx");const useState = __vite__cjsImport0_react["useState"];const _jsxDEV = __vite__cjsImport5_react_jsxDevRuntime["jsxDEV"];import __vite__cjsImport0_react from "/node_modules/.vite/deps/react.js?v=fb72e7e4";
import { Routes, Route } from "/node_modules/.vite/deps/react-router-dom.js?v=fb72e7e4";
import { UsersPage } from "/src/pages/UsersPage.jsx?t=1786958910609";
import { UserDetailPage } from "/src/pages/UserDetailPage.jsx?t=1786957584966";
import { SelectedUserContext } from "/src/context/SelectedUserContext.js";
var _jsxFileName = "/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/App.jsx";
import __vite__cjsImport5_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=fb72e7e4";
var _s = $RefreshSig$();
function App() {
	_s();
	const [selectedUser, setSelectedUser] = useState(null);
	return /* @__PURE__ */ _jsxDEV(SelectedUserContext.Provider, {
		value: {
			selectedUser,
			setSelectedUser
		},
		children: /* @__PURE__ */ _jsxDEV(Routes, { children: [/* @__PURE__ */ _jsxDEV(Route, {
			path: "/",
			element: /* @__PURE__ */ _jsxDEV(UsersPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 13,
				columnNumber: 34
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 13,
			columnNumber: 9
		}, this), /* @__PURE__ */ _jsxDEV(Route, {
			path: "/users/:id",
			element: /* @__PURE__ */ _jsxDEV(UserDetailPage, {}, void 0, false, {
				fileName: _jsxFileName,
				lineNumber: 14,
				columnNumber: 43
			}, this)
		}, void 0, false, {
			fileName: _jsxFileName,
			lineNumber: 14,
			columnNumber: 9
		}, this)] }, void 0, true, {
			fileName: _jsxFileName,
			lineNumber: 12,
			columnNumber: 7
		}, this)
	}, void 0, false, {
		fileName: _jsxFileName,
		lineNumber: 11,
		columnNumber: 5
	}, this);
}
_s(App, "HNnFF/Eedh53ViIinNyGSRZp+EQ=");
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
import * as RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== 'undefined' && self instanceof WorkerGlobalScope;
import * as __vite_react_currentExports from "/src/App.jsx?t=1786958910609";
if (import.meta.hot && !inWebWorker) {
  if (!window.$RefreshReg$) {
    throw new Error(
      "@vitejs/plugin-react can't detect preamble. Something is wrong."
    );
  }

  const currentExports = __vite_react_currentExports;
  queueMicrotask(() => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/App.jsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports) return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate("/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/App.jsx", currentExports, nextExports);
      if (invalidateMessage) import.meta.hot.invalidate(invalidateMessage);
    });
  });
}
function $RefreshReg$(type, id) { return RefreshRuntime.register(type, "/Users/deuexsolutions/Desktop/Dashboard/User-dashboard/src/App.jsx" + ' ' + id); }
function $RefreshSig$() { return RefreshRuntime.createSignatureFunctionForTransform(); }

//# sourceMappingURL=data:application/json;base64,eyJtYXBwaW5ncyI6IkFBQUEsU0FBUyxnQkFBZ0I7QUFDekIsU0FBUyxRQUFRLGFBQWE7QUFDOUIsU0FBUyxpQkFBaUI7QUFDMUIsU0FBUyxzQkFBc0I7QUFDL0IsU0FBUywyQkFBMkI7Ozs7QUFFcEMsU0FBUyxNQUFNOztDQUNiLE1BQU0sQ0FBQyxjQUFjLG1CQUFtQixTQUFTLElBQUk7Q0FFckQsT0FDRSx3QkFBQyxvQkFBb0IsVUFBckI7RUFBOEIsT0FBTztHQUFFO0dBQWM7RUFBZ0I7WUFDbkUsd0JBQUMsUUFBRCxhQUNFLHdCQUFDLE9BQUQ7R0FBTyxNQUFLO0dBQUksU0FBUyx3QkFBQyxXQUFELENBQVk7Ozs7O0VBQUk7Ozs7WUFDekMsd0JBQUMsT0FBRDtHQUFPLE1BQUs7R0FBYSxTQUFTLHdCQUFDLGdCQUFELENBQWlCOzs7OztFQUFJOzs7O1VBQ2pEOzs7OztDQUNvQjs7Ozs7QUFFbEM7OztBQUVBLGVBQWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLmpzeCJdLCJ2ZXJzaW9uIjozLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTdGF0ZSB9IGZyb20gJ3JlYWN0J1xuaW1wb3J0IHsgUm91dGVzLCBSb3V0ZSB9IGZyb20gJ3JlYWN0LXJvdXRlci1kb20nXG5pbXBvcnQgeyBVc2Vyc1BhZ2UgfSBmcm9tICcuL3BhZ2VzL1VzZXJzUGFnZSdcbmltcG9ydCB7IFVzZXJEZXRhaWxQYWdlIH0gZnJvbSAnLi9wYWdlcy9Vc2VyRGV0YWlsUGFnZSdcbmltcG9ydCB7IFNlbGVjdGVkVXNlckNvbnRleHQgfSBmcm9tICcuL2NvbnRleHQvU2VsZWN0ZWRVc2VyQ29udGV4dCdcblxuZnVuY3Rpb24gQXBwKCkge1xuICBjb25zdCBbc2VsZWN0ZWRVc2VyLCBzZXRTZWxlY3RlZFVzZXJdID0gdXNlU3RhdGUobnVsbClcblxuICByZXR1cm4gKFxuICAgIDxTZWxlY3RlZFVzZXJDb250ZXh0LlByb3ZpZGVyIHZhbHVlPXt7IHNlbGVjdGVkVXNlciwgc2V0U2VsZWN0ZWRVc2VyIH19PlxuICAgICAgPFJvdXRlcz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvXCIgZWxlbWVudD17PFVzZXJzUGFnZSAvPn0gLz5cbiAgICAgICAgPFJvdXRlIHBhdGg9XCIvdXNlcnMvOmlkXCIgZWxlbWVudD17PFVzZXJEZXRhaWxQYWdlIC8+fSAvPlxuICAgICAgPC9Sb3V0ZXM+XG4gICAgPC9TZWxlY3RlZFVzZXJDb250ZXh0LlByb3ZpZGVyPlxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IEFwcCJdfQ==